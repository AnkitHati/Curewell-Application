import React, { useEffect, useState } from "react";
import useAuth from "../hooks/useAuth";
import Table from "../components/Table";
import "../styles/Prescriptions.css";

const Prescriptions = () => {
  const { user } = useAuth();
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPrescriptions = async () => {
      try {
        const response = await fetch(`/api/prescriptions?userId=${user.id}`);
        if (!response.ok) {
          throw new Error("Failed to fetch prescriptions");
        }
        const data = await response.json();
        setPrescriptions(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchPrescriptions();
    }
  }, [user]);

  const columns = ["Doctor", "Medication", "Dosage", "Date Issued", "Status"];

  return (
    <div className="prescriptions-container">
      <h2>Your Prescriptions</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && <Table columns={columns} data={prescriptions} />}
    </div>
  );
};

export default Prescriptions;
