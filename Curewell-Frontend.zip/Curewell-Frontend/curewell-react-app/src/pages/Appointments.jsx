import React, { useEffect, useState } from "react";
import useFetch from "../hooks/useFetch";
import Table from "../components/Table";
import "../styles/Appointments.css";

const Appointments = () => {
  const { data, loading, error } = useFetch("/api/appointments");
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    if (data) {
      setAppointments(data);
    }
  }, [data]);

  const columns = ["Patient Name", "Doctor", "Date", "Time", "Status"];

  return (
    <div className="appointments-container">
      <h2>Appointments</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && (
        <Table columns={columns} data={appointments} />
      )}
    </div>
  );
};

export default Appointments;
