import React from "react";
import { Link } from "react-router-dom";
import "../styles/Home.css";

const Home = () => {
  return (
    <div className="home-container">
      <h1>Welcome to CureWell</h1>
      <p>Your trusted healthcare management solution.</p>
      <div className="home-buttons">
        <Link to="/login" className="btn btn-primary">Login</Link>
        <Link to="/dashboard" className="btn btn-secondary">Go to Dashboard</Link>
      </div>
    </div>
  );
};

export default Home;