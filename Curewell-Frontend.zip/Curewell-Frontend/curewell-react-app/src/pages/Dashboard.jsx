import React, { useEffect, useState } from "react";
import useAuth from "../hooks/useAuth";
import useFetch from "../hooks/useFetch";
import Card from "../components/Card";
import "../styles/Dashboard.css";

const Dashboard = () => {
  const { user } = useAuth();
  const { data: stats, loading, error } = useFetch("/api/dashboard-stats");
  const [dashboardData, setDashboardData] = useState(null);

  useEffect(() => {
    if (stats) {
      setDashboardData(stats);
    }
  }, [stats]);

  return (
    <div className="dashboard-container">
      <h2>Welcome, {user?.name || "User"}!</h2>
      {loading && <p>Loading dashboard...</p>}
      {error && <p className="error">{error}</p>}
      {dashboardData && (
        <div className="dashboard-widgets">
          <Card title="Total Appointments" description={dashboardData.appointments} />
          <Card title="Pending Prescriptions" description={dashboardData.prescriptions} />
          <Card title="Reports Generated" description={dashboardData.reports} />
        </div>
      )}
    </div>
  );
};

export default Dashboard;