import React, { useEffect, useState } from "react";
import useAuth from "../hooks/useAuth";
import Table from "../components/Table";
import "../styles/Reports.css";

const Reports = () => {
  const { user } = useAuth();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const response = await fetch(`/api/reports?userId=${user.id}`);
        if (!response.ok) {
          throw new Error("Failed to fetch reports");
        }
        const data = await response.json();
        setReports(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchReports();
    }
  }, [user]);

  const columns = ["Report Name", "Date Generated", "Doctor", "Status"];

  return (
    <div className="reports-container">
      <h2>Your Reports</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      {!loading && !error && <Table columns={columns} data={reports} />}
    </div>
  );
};

export default Reports;
