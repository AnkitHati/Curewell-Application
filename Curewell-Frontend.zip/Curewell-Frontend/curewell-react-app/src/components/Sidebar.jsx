import React from "react";
import { Link } from "react-router-dom";
import "../styles/Sidebar.css";

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <ul className="sidebar-menu">
        <li><Link to="/dashboard">🏠 Dashboard</Link></li>
        <li><Link to="/appointments">📅 Appointments</Link></li>
        <li><Link to="/prescriptions">💊 Prescriptions</Link></li>
        <li><Link to="/reports">📂 Reports</Link></li>
        <li><Link to="/profile">👤 Profile</Link></li>
      </ul>
    </aside>
  );
};

export default Sidebar;
