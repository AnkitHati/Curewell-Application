import { apiRequest } from "./apiConfig";

export const loginUser = async (email, password) => {
  return await apiRequest("/api/login", "POST", { email, password });
};

export const registerUser = async (userData) => {
  return await apiRequest("/api/register", "POST", userData);
};

export const fetchUserProfile = async (userId, token) => {
  return await apiRequest(`/api/profile?userId=${userId}`, "GET", null, token);
};