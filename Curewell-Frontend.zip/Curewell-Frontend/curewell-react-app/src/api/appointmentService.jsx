import { apiRequest } from "./apiConfig";

export const fetchAppointments = async (userId, token) => {
  return await apiRequest(`/api/appointments?userId=${userId}`, "GET", null, token);
};

export const bookAppointment = async (appointmentData, token) => {
  return await apiRequest("/api/appointments", "POST", appointmentData, token);
};

export const cancelAppointment = async (appointmentId, token) => {
  return await apiRequest(`/api/appointments/${appointmentId}`, "DELETE", null, token);
};
