import { apiRequest } from "./apiConfig";

export const fetchPrescriptions = async (userId, token) => {
  return await apiRequest(`/api/prescriptions?userId=${userId}`, "GET", null, token);
};

export const requestPrescriptionRefill = async (prescriptionId, token) => {
  return await apiRequest(`/api/prescriptions/${prescriptionId}/refill`, "POST", null, token);
};