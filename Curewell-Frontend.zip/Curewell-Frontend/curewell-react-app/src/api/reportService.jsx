import { apiRequest } from "./apiConfig";

export const fetchReports = async (userId, token) => {
  return await apiRequest(`/api/reports?userId=${userId}`, "GET", null, token);
};

export const downloadReport = async (reportId, token) => {
  return await apiRequest(`/api/reports/${reportId}/download`, "GET", null, token);
};